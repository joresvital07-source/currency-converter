const API_URL = 'https://api.exchangerate-api.com/v4/latest/';
const SYMBOLES = {
    USD: '$', EUR: '€', GBP: '£', XOF: 'CFA', XAF: 'CFA',
    NGN: '₦', ZAR: 'R', JPY: '¥'
};

const el = {
    montant: document.getElementById('montant'),
    source: document.getElementById('source'),
    cible: document.getElementById('cible'),
    swap: document.getElementById('swap'),
    convertir: document.getElementById('convertir'),
    resultat: document.getElementById('resultat'),
    valeur: document.getElementById('valeur'),
    taux: document.getElementById('taux'),
    liste: document.getElementById('liste-historique'),
    maj: document.getElementById('maj')
};

let historique = JSON.parse(localStorage.getItem('historique')) || [];

function formatDate() {
    return new Date().toLocaleString('fr-FR', {
        day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
    });
}

function afficherHistorique() {
    el.liste.innerHTML = historique.slice(-5).reverse().map(h => 
        `<li>${h.date} — ${h.montant} ${h.source} = <strong>${h.resultat} ${h.cible}</strong></li>`
    ).join('') || '<li>Aucune conversion encore</li>';
}

function ajouterHistorique(montant, source, resultat, cible) {
    historique.push({ date: formatDate(), montant, source, resultat, cible });
    if (historique.length > 10) historique.shift();
    localStorage.setItem('historique', JSON.stringify(historique));
    afficherHistorique();
}

async function convertir() {
    const montant = parseFloat(el.montant.value);
    const source = el.source.value;
    const cible = el.cible.value;

    if (!montant || montant <= 0) {
        alert('Entre un montant valide');
        return;
    }

    el.convertir.textContent = 'Conversion...';
    el.convertir.disabled = true;

    try {
        const res = await fetch(`${API_URL}${source}`);
        const data = await res.json();
        const taux = data.rates[cible];
        const resultat = (montant * taux).toFixed(2);

        el.valeur.textContent = `${resultat} ${SYMBOLES[cible] || cible}`;
        el.taux.textContent = `1 ${source} = ${taux.toFixed(4)} ${cible}`;
        el.resultat.classList.remove('hidden');
        el.maj.textContent = `Dernière mise à jour : ${formatDate()}`;

        ajouterHistorique(montant, source, resultat, cible);
    } catch (err) {
        alert('Erreur de connexion. Vérifie ta connexion internet.');
        console.error(err);
    } finally {
        el.convertir.textContent = 'Convertir';
        el.convertir.disabled = false;
    }
}

el.swap.addEventListener('click', () => {
    const temp = el.source.value;
    el.source.value = el.cible.value;
    el.cible.value = temp;
});

el.convertir.addEventListener('click', convertir);
el.montant.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') convertir();
});

afficherHistorique();
